﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ePizzaHub.Entites
{
   public class OrderItem
    {
        public OrderItem()
        {
            //required by EF
        }

        public OrderItem(int itemId,decimal unitprice,int qty,decimal total)
        {
            ItemId = itemId;
            UnitPrice = unitprice;
            Quantity = qty;
            Total = total;
        }

        public int Id { get; set; }

        public int ItemId { get; set; }
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        public decimal Total { get; set; }

        public string OrderId { get; set; }

        public virtual Order Order { get; set; }
    }
}
