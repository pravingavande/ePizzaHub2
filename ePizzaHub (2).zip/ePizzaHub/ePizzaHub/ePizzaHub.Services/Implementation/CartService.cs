﻿using ePizzaHub.Entites;
using ePizzaHub.Repositiories.Interfaces;
using ePizzaHub.Repositiories.Models;
using ePizzaHub.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ePizzaHub.Services.Implementation
{
    public class CartService : ICartService
    {
        private readonly ICartRepository _cartRepo;
        private readonly IRepository<CartItem> _cartItem;

        public CartService(ICartRepository cartRepo, IRepository<CartItem> cartItem)
        {
            _cartRepo = cartRepo;
            _cartItem = cartItem;
        }
        public Cart AddItem(int UserId, Guid CartId, int ItemId, decimal UnitPrice, int quantity)
        {
            throw new NotImplementedException();
        }

        public int DeleteItem(Guid cartId, int ItemId)
        {
            return _cartRepo.DeleteItem(cartId, ItemId);

        }
       
        public int GetCartCount(Guid cartId)
        {
            var cart = _cartRepo.GetCart(cartId);
            if(cart !=null)
            {
                return cart.Items.Count();
            }
            else
            {
                return 0;
            }
            
        }

        public CartModel GetCartDetail(Guid cartId)
        {
            var model = _cartRepo.GetCartDetails(cartId);
            if(model !=null && model.Items.Count>0)
            {
                decimal subTotal = 0;
                foreach(var item in model.Items)
                {
                    item.Total = item.UnitPrice * item.Quantity;
                    subTotal += item.Total;
                }

                model.Total = subTotal;

                //5% Tax
                model.Tax = Math.Round((model.Total*5)/100,2);
                model.GrandTotal = model.Tax + model.Total;
            }
            return model;
        }

        public int UpdateCart(Guid cartId, int UserId)
        {
            throw new NotImplementedException();
        }

        public int UpdateQuantity(Guid cartId, int Id, int quantity)
        {
            throw new NotImplementedException();
        }
    }
}
