﻿using ePizzaHub.Entites;
using System;
using System.Collections.Generic;
using System.Text;

namespace ePizzaHub.Services.Interface
{
   public interface ICatalogService
    {
        IEnumerable<Category> GetCategories();
        IEnumerable<ItemType> GetItemTypes();

        IEnumerable<Item> GetItems();

        Item GetItem(int id);

        void AddItem(Item item);

        void UpdateItem(Item item);
        void DeleteItem(int Id);

    }

}

