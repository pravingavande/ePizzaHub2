﻿using ePizzaHub.Entites;
using ePizzaHub.Repositiories.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ePizzaHub.Repositiories.Interfaces
{
   public interface ICartRepository :IRepository<Cart>
    {
        Cart GetCart(Guid CartId);

        CartModel GetCartDetails(Guid CartId);

        int DeleteItem(Guid CartId, int ItemId);

        int UpdateQuantity(Guid CartId, int ItemId, int Quantity);

        int UpdateCart(Guid CartId,int userId);


    }
}
