﻿using ePizzaHub.Entites;
using ePizzaHub.Repositiories.Interfaces;
using ePizzaHub.Repositiories.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ePizzaHub.Repositiories.Implementation
{
    public class CartRepository : Repository<Cart>, ICartRepository
    {
        private AppDbContext dbContext { 
            get
            {
                return _dbContext as AppDbContext;
            } 
        }

        public CartRepository(DbContext dbContext):base(dbContext)
        {

        }

        public Cart GetCart(Guid CartId)
        {
            return dbContext.Carts.Include("Items").Where(p => p.Id == CartId && 
            p.IsActive == true).FirstOrDefault();

        }

        public CartModel GetCartDetails(Guid CartId)
        {
            var model = (from cart in dbContext.Carts
                         where cart.Id == CartId && cart.IsActive == true
                         select new CartModel
                         {
                             Id = cart.Id,
                             UserId = cart.UserId,
                             CreatedDate = cart.CreatedDate,
                             Items = (from CartItem in dbContext.CartItems
                                      join item in dbContext.Items
                                      on CartItem.ItemId equals item.Id
                                      where CartItem.CartId == CartId
                                      select new ItemModel
                                      {
                                          Id = CartItem.Id,
                                          Name = item.Name,
                                          Description = item.Description,
                                          ImageUrl=item.ImageUrl,
                                          Quantity=CartItem.Quantity,
                                          ItemId=item.Id,
                                          UnitPrice=item.UnitPrice
                                      }).ToList()

                         }).FirstOrDefault();
            return model;
        }

        public int DeleteItem(Guid CartId, int ItemId)
        {
            var item = dbContext.CartItems.Where(ci => ci.CartId == CartId && ci.Id == ItemId).FirstOrDefault();
            if (item != null)
            {

                dbContext.CartItems.Remove(item);
                return dbContext.SaveChanges();
            }
            else
            {
                return 0;
            }
        }



     

        public int UpdateQuantity(Guid CartId, int ItemId, int Quantity)
        {
            bool flag = false;
            var cart = GetCart(CartId);
            if(cart !=null)
            {
                for(int i=0;i< cart.Items.Count;i++)
                {
                    if(cart.Items[i].Id==ItemId)
                    {
                        flag = true;

                        //for minus the qty
                        if(Quantity <0 && cart.Items[i].Quantity >1)
                        {
                            cart.Items[i].Quantity += Quantity;

                        }
                        else if(Quantity > 0)
                        {
                            cart.Items[i].Quantity += Quantity;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                if (flag)
                    return dbContext.SaveChanges();
            }
            return 0;
        }

        public int UpdateCart(Guid CartId, int userId)
        {
            Cart cart = GetCart(CartId);
            cart.UserId = userId;
            return dbContext.SaveChanges();

        }
    }
}
